/**
 * SQL Dump created with Backup for WordPress
 *
 * http://hel.io/wordpress/backup
 */

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/* Dump of table `wp_commentmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* Dump of table `wp_comments`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* Dump of table `wp_duplicator_packages`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_duplicator_packages`;

CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/* Dump of table `wp_links`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* Dump of table `wp_options`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_options` WRITE;
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 3, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 4, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 5, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 6, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 7, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 8, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 9, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 10, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 11, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 12, '', 10, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 13, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 14, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 15, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 16, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 17, '', 110, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 18, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 19, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 20, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 21, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 22, '', 10, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 23, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 24, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 25, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 26, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 27, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 28, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 29, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 30, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 31, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 32, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 33, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 34, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 35, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 36, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 37, '', 2, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 38, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 39, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 40, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 41, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 42, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 43, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 44, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 45, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 46, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 47, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 48, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 49, '', 33056, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 50, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 51, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 52, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 53, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 54, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 55, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 56, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 57, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 58, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 59, '', 150, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 60, '', 150, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 61, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 62, '', 300, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 63, '', 300, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 64, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 65, '', 1024, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 66, '', 1024, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 67, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 68, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 69, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 70, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 71, '', 14, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 72, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 73, '', 5, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 74, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 75, '', 50, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 76, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 77, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 78, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 79, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 80, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 81, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 82, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 83, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 84, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 85, '', 4, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 86, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 87, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 88, '', 30133, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 89, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 90, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 91, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 92, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 93, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 94, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 95, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 96, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 127, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 135, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 149, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 150, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 151, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 152, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 153, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 163, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 287, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 288, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 289, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 290, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 291, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 292, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 293, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 294, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 295, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 296, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 297, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 298, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 299, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 300, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 301, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 302, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 303, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 304, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 307, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 308, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 309, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 310, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 311, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 312, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 313, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 314, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 315, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 316, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 317, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 318, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 319, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 320, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 321, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 322, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 323, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 324, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 325, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 326, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 327, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 328, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 374, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 542, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1804, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1896, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1908, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1915, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1917, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1923, '', 1442360985, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1924, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1925, '', 1442360985, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1926, '', 1442317785, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1935, '', 1442360986, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1936, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1946, '', 1442923037, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1947, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1950, '', 1, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1963, '', 1442923186, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 1964, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2007, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2008, '', 0, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2009, '', 1442524324, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2010, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2011, '', 1442524324, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2012, '', 1442481124, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2013, '', 1442524325, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2014, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2015, '', 1442524325, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2016, '', 1442481125, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2017, '', 1442524326, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2018, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2019, '', 1442524326, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2020, '', 1442481126, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2021, '', 1442567666, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2022, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2023, '', 1442524326, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2024, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2261, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2323, '', 1448970261.6806170940399169921875, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2324, '', 1449056661, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2325, '', 1448970261, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2327, '', 1448972063, '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2328, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2329, '', '', '' );
INSERT INTO `wp_options` ( option_id, option_name, option_value, autoload ) VALUES ( 2330, '', '', '' );

UNLOCK TABLES;

/* Dump of table `wp_postmeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=575 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_postmeta` WRITE;
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 2, 4, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 3, 4, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 4, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 5, 6, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 6, 6, '', 4 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 7, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 8, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 9, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 10, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 11, 6, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 34, 4, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 57, 23, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 58, 23, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 59, 25, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 60, 25, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 90, 32, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 91, 32, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 115, 4, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 123, 54, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 124, 54, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 125, 55, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 126, 55, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 127, 56, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 128, 56, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 129, 57, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 130, 57, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 131, 57, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 132, 54, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 133, 54, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 134, 55, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 135, 55, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 136, 56, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 137, 56, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 138, 57, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 175, 84, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 176, 84, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 177, 84, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 201, 97, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 202, 97, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 203, 97, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 224, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 225, 101, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 226, 101, '', 32 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 227, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 228, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 229, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 230, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 231, 101, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 260, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 261, 105, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 262, 105, '', 4 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 263, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 264, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 265, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 266, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 267, 105, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 269, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 270, 106, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 271, 106, '', 97 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 272, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 273, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 274, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 275, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 276, 106, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 287, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 288, 108, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 289, 108, '', 32 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 290, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 291, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 292, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 293, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 294, 108, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 305, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 306, 110, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 307, 110, '', 23 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 308, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 309, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 310, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 311, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 312, 110, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 335, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 336, 114, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 337, 114, '', 23 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 338, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 339, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 340, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 341, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 342, 114, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 355, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 356, 129, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 357, 129, '', 129 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 358, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 359, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 360, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 361, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 362, 129, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 364, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 365, 130, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 366, 130, '', 130 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 367, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 368, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 369, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 370, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 371, 130, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 373, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 374, 131, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 375, 131, '', 131 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 376, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 377, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 378, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 379, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 380, 131, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 391, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 392, 147, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 393, 147, '', 147 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 394, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 395, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 396, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 397, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 398, 147, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 400, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 401, 148, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 402, 148, '', 97 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 403, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 404, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 405, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 406, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 407, 148, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 417, 151, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 418, 151, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 419, 152, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 420, 152, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 421, 153, '', 2 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 422, 153, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 423, 154, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 424, 154, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 425, 155, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 426, 155, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 429, 157, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 430, 157, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 431, 157, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 432, 157, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 433, 157, '', 167 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 434, 157, '', 166 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 435, 157, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 436, 157, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 437, 160, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 438, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 439, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 440, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 441, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 442, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 443, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 444, 160, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 445, 161, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 446, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 447, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 448, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 449, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 450, 161, '', 160 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 451, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 452, 161, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 453, 162, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 454, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 455, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 456, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 457, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 458, 162, '', 161 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 459, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 460, 162, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 461, 163, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 462, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 463, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 464, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 465, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 466, 163, '', 162 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 467, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 468, 163, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 469, 164, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 470, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 471, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 472, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 473, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 474, 164, '', 163 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 475, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 476, 164, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 477, 165, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 478, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 479, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 480, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 481, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 482, 165, '', 164 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 483, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 484, 165, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 485, 166, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 486, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 487, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 488, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 489, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 490, 166, '', 165 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 491, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 492, 166, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 493, 167, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 494, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 495, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 496, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 497, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 498, 167, '', 157 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 499, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 500, 167, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 505, 23, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 516, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 517, 207, '', 210 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 518, 207, '', 207 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 519, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 520, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 521, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 522, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 523, 207, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 525, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 526, 208, '', 210 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 527, 208, '', 208 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 528, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 529, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 530, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 531, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 532, 208, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 534, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 535, 209, '', 210 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 536, 209, '', 209 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 537, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 538, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 539, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 540, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 541, 209, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 543, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 544, 210, '', 0 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 545, 210, '', 210 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 546, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 547, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 548, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 549, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 550, 210, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 552, 32, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 553, 216, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 554, 216, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 555, 217, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 556, 217, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 557, 217, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 558, 216, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 567, 237, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 568, 237, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 569, 237, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 570, 238, '', 1 );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 571, 238, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 572, 238, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 573, 237, '', '' );
INSERT INTO `wp_postmeta` ( meta_id, post_id, meta_key, meta_value ) VALUES ( 574, 238, '', '' );

UNLOCK TABLES;

/* Dump of table `wp_posts`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_posts` WRITE;
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 4, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 5, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 6, 2, '', '', '', '', '', '', '', '', '', 6, '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 10, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 11, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 12, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 13, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 14, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 15, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 16, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 17, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 23, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 24, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 25, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 26, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 25, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 32, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 33, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 32, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 38, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 39, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 40, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 41, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 54, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 55, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 56, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 57, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 58, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 55, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 59, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 56, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 60, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 57, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 84, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 85, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 84, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 97, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 98, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 101, 2, '', '', '', '', '', '', '', '', '', 101, '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 105, 2, '', '', '', '', '', '', '', '', '', 105, '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 106, 2, '', '', '', '', '', '', '', '', '', 106, '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 108, 2, '', '', '', '', '', '', '', '', '', 108, '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 110, 2, '', '', '', '', '', '', '', '', '', 110, '', '', '', '', '', 0, '', 8, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 114, 2, '', '', '', '', '', '', '', '', '', 114, '', '', '', '', '', 0, '', 5, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 129, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 1, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 130, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 2, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 131, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 133, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 134, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 135, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 136, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 137, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 138, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 139, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 140, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 141, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 142, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 143, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 144, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 145, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 146, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 147, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 3, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 148, 2, '', '', '', '', '', '', '', '', '', 148, '', '', '', '', '', 0, '', 4, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 151, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 152, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 153, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 154, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 155, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 156, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 154, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 157, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 160, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 161, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 162, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 163, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 164, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 165, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 166, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 167, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 168, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 169, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 170, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 171, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 172, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 173, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 174, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 175, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 177, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 178, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 179, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 180, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 181, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 182, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 183, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 184, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 185, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 186, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 188, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 189, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 190, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 191, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 192, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 193, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 194, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 195, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 196, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 197, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 198, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 199, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 200, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 201, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 202, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 203, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 204, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 205, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 206, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 207, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 7, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 208, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 6, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 209, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 5, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 210, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 4, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 211, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 4, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 212, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 32, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 213, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 214, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 215, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 216, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 217, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 218, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 219, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 220, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 221, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 222, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 223, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 224, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 225, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 226, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 227, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 228, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 230, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 231, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 232, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 233, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 234, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 97, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 235, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 236, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 23, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 237, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );
INSERT INTO `wp_posts` ( ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count ) VALUES ( 238, 2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, '', '', 0 );

UNLOCK TABLES;

/* Dump of table `wp_term_relationships`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_term_relationships` WRITE;
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 6, 2, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 101, 2, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 105, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 106, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 108, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 110, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 114, 2, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 129, 5, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 130, 5, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 131, 5, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 147, 2, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 148, 2, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 207, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 208, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 209, 4, 0 );
INSERT INTO `wp_term_relationships` ( object_id, term_taxonomy_id, term_order ) VALUES ( 210, 4, 0 );

UNLOCK TABLES;

/* Dump of table `wp_term_taxonomy`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_term_taxonomy` WRITE;
INSERT INTO `wp_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 1, 1, '', '', 0, 0 );
INSERT INTO `wp_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 2, 2, '', '', 0, 5 );
INSERT INTO `wp_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 4, 4, '', '', 0, 8 );
INSERT INTO `wp_term_taxonomy` ( term_taxonomy_id, term_id, taxonomy, description, parent, count ) VALUES ( 5, 5, '', '', 0, 3 );

UNLOCK TABLES;

/* Dump of table `wp_terms`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_terms` WRITE;
INSERT INTO `wp_terms` ( term_id, name, slug, term_group ) VALUES ( 1, '', '', 0 );
INSERT INTO `wp_terms` ( term_id, name, slug, term_group ) VALUES ( 2, '', '', 0 );
INSERT INTO `wp_terms` ( term_id, name, slug, term_group ) VALUES ( 4, '', '', 0 );
INSERT INTO `wp_terms` ( term_id, name, slug, term_group ) VALUES ( 5, '', '', 0 );

UNLOCK TABLES;

/* Dump of table `wp_usermeta`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_usermeta` WRITE;
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 37, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 38, 2, '', 10 );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 39, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 40, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 41, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 42, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 43, 2, '', 240 );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 44, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 45, 2, '', 2 );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 46, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 47, 2, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 48, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 49, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 50, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 51, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 52, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 53, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 54, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 55, 3, '', 0 );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 56, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 57, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 58, 3, '', 10 );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 59, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 60, 3, '', '' );
INSERT INTO `wp_usermeta` ( umeta_id, user_id, meta_key, meta_value ) VALUES ( 61, 3, '', 241 );

UNLOCK TABLES;

/* Dump of table `wp_users`
 * ------------------------------------------------------------*/

DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `wp_users` WRITE;
INSERT INTO `wp_users` ( ID, user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name ) VALUES ( 2, '', '', '', '', '', '', '', 0, '' );
INSERT INTO `wp_users` ( ID, user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_activation_key, user_status, display_name ) VALUES ( 3, '', '', '', '', '', '', '', 0, '' );

UNLOCK TABLES;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
